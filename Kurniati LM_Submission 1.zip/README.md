# Submission Pertama: Menyelesaikan Permasalahan Human Resources

## Set Up Environtment

conda create --name main-ds python=3.11

conda activate main-ds

pip streamlit pandas numpy scikit-learn==1.5.0 joblib category_encoders

## Run steamlit app

streamlit run model_dashboard.py

Link github repository: https://github.com/klaelimunifah/Submission-Pertama--Menyelesaikan-Permasalahan-Human-Resources)

Link main dashboard looker studio: https://lookerstudio.google.com/reporting/bfe26f76-2840-4202-bee9-2f7f7f5e6c9d

Link prediction model dashboard streamlit: https://submission-pertama--menyelesaikan-permasalahan-human-resources.streamlit.app/
 
